if c=1: return src_a + src_b
if c=2: return src_a - src_b
if c=3: return src_a & src_b
if c=4: return src_a | src_b
if c=5: return src_a ^ src_b
default: return src_a