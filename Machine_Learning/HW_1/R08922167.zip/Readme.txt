Coursera 的 15~20 題在 HW_1_coursera.ipynb

上課作業 的 6~8 在 HW_1_6~8.ipynb

